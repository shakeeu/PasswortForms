﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace PasswortBibliothek
{
    public class PasswortVerwaltung
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source= Kundenverwaltung.accdb");

        OleDbCommand command = null;

        OleDbDataReader dataReader = null;


        public OleDbDataReader laden()
        {
            try
            {
                con.Open();
                command = new OleDbCommand("select mitnr from passwort", con);
                dataReader = command.ExecuteReader();
            }
            catch(Exception a)
            {
                throw a;
            }
            return dataReader;
        }



        public OleDbDataReader select(int nummer)
        {
            try
            {
                con.Open();
                command = new OleDbCommand("select mitnr,mitname from passwort where mitnr=" + nummer, con);
                dataReader = command.ExecuteReader();
                
                
            }
            catch(Exception a)
            {
                throw a;
            }
            

            return dataReader;
        }

        public void update(string passwort, int nummer)
        {
            con.Open();
            command = new OleDbCommand("update passwort set mitpasswort= '"+passwort+"' where mitnr="+nummer,con);
            command.ExecuteNonQuery();
            
        }


        

        public void close()
        {
            con.Close();
        }
    }
}
